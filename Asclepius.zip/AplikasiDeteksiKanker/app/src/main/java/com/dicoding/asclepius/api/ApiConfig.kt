package com.dicoding.asclepius.api

object ApiConfig {
    const val KEY = "f7bda15d534841898809e0ea1996fcbe"
}